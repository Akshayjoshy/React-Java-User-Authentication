package com.demo.backendtrainingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendtrainingprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendtrainingprojectApplication.class, args);
	}

}
