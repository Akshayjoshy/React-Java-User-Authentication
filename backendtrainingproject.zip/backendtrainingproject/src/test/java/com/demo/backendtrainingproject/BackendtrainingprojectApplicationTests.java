package com.demo.backendtrainingproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendtrainingprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
